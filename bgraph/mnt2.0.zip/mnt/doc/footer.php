

		</div>
		</div>

		 <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="../access/login">Logout</a>
        </div>
      </div>
    </div>
  </div>
	</div>

	<!-- Bootstrap core JavaScript-->
	<script type="text/javascript" src="../js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="../js/jquery-ui-1.12.1/jquery-ui.min.js"></script>	
	<script type="text/javascript"  src="../js/bootstrap.min.js"></script>
<script type="text/javascript"  src="../DataTables/datatables.min.js"></script>

<script src="../js/flatpickr.js"></script>
<script src="../js/excel-bootstrap-table-filter-bundle.js"></script>


<!-- moment js -->
<script src='../js/moment.min.js'></script>
<script src='../js/moment-with-locales.js'></script>

<script src='../js/jspdf.min.js'></script>
<script src='../js/html2canvas.js'></script>

<script src='../js/html2pdf.bundle.js'></script>
<script src="../js/es6-promise.auto.min.js"></script>

<script src="../js/addHTML.js"></script>
	
 <script type="text/javascript" src="../js/select2.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script type="text/javascript"  src="../assets/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="../assets/chart.js/Chart.min.js"></script>
  <script src="../assets/datatables/jquery.dataTables.js"></script>
  <script src="../assets/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  
  <script src="../js/bg-admin.min.js"></script>
  <script src="../js/buttons/dataTables.buttons.js"></script>
  <script src="../js/buttons/buttons.html5.js"></script>
  <script src="../js/buttons/buttons.flash.js"></script>
  <script src="../js/buttons/buttons.dataTables.js"></script>
  <script src="../js/buttons/buttons.print.js"></script>
  <script src="../js/buttons/buttons.bootstrap4.js"></script>
    <script src="../js/buttons/jszip.min.js"></script>
      <script src="../js/buttons/pdfmake.min.js"></script>
        <script src="../js/buttons/vfs_fonts.js"></script>
        
        <script src="../js/buttons/dataTables.fixedColumns.min.js"></script>
        <script src="../js/buttons/dataTables.select.min.js"></script>
		
		<script src="../js/sweetalert.min.js"></script>
		<script src="../js/excel-bootstrap-table-filter-bundle.js"></script>
		
		
		<script src="../js/popper.min.js"></script>
		<script src="../js/tooltip.min.js"></script>
		
		<script src="../js/dataTables.altEditor.js" ></script>
		<script src="../js/bootstrap-material-design.js"></script>	


  </body>

</html>
