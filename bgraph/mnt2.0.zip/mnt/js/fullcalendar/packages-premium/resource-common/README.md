
# FullCalendar Resources Common Plugin

Offers base support for resources. Required for all resource-related plugins.

[View the docs &raquo;](https://fullcalendar.io/docs/scheduler)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar-scheduler)
