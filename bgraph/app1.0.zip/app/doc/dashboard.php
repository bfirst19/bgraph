<?php include 'header.php'; ?>


<h1>This is dashboard window for status</h1>

<?php include 'footer.php'; ?>