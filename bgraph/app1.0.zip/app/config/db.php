
<?php
$con = mysqli_connect("localhost","bgraph","Bgraph2019*","badm");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
