	<!-- Bootstrap core JavaScript-->
  <script src="../assets/jquery/jquery.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../assets/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="../assets/chart.js/Chart.min.js"></script>
  <script src="../assets/datatables/jquery.dataTables.js"></script>
  <script src="../assets/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/bg-admin.min.js"></script>
  <script src="../js/buttons/dataTables.buttons.js"></script>
  <script src="../js/buttons/buttons.html5.js"></script>
  <script src="../js/buttons/buttons.flash.js"></script>
  <script src="../js/buttons/buttons.dataTables.js"></script>
  <script src="../js/buttons/buttons.print.js"></script>
  <script src="../js/buttons/buttons.bootstrap4.js"></script>
    <script src="../js/buttons/jszip.min.js"></script>
      <script src="../js/buttons/pdfmake.min.js"></script>
        <script src="../js/buttons/vfs_fonts.js"></script>
        
        <script src="../js/buttons/dataTables.fixedColumns.min.js"></script>
        <script src="../js/buttons/dataTables.select.min.js"></script>



  </body>

</html>
